"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.authenticateUser = exports.handler = void 0;
const validUsers = {
    "naji.naser+31@moo.com": {
        password: "12",
        emailAddress: "naji.naser+31@moo.com"
    },
    "philip.cadwallader+30@moo.com": {
        password: "1234",
        emailAddress: "philip.cadwallader+30@moo.com"
    },
    "philip.cadwallader+31@moo.com": {
        password: "31",
        emailAddress: "philip.cadwallader+31@moo.com"
    },
    "philip.cadwallader+32@moo.com": {
        password: "32",
        emailAddress: "philip.cadwallader+32@moo.com"
    },
    "naji@moo.com": {
        password: "12",
        emailAddress: "naji@moo.com"
    },
    "naji@oo.com": {
        password: "12",
        emailAddress: "naji@oo.com"
    },
};
// Replace this mock with a call to a real authentication service.
const authenticateUser = (email, password) => {
    const validSingleUsers = validUsers[email];
    // we call Site
    if (validSingleUsers.emailAddress === email && validSingleUsers.password === password) {
        return validSingleUsers;
    }
    else {
        return null;
    }
};
exports.authenticateUser = authenticateUser;
const handler = (event) => __awaiter(void 0, void 0, void 0, function* () {
    console.log("event Feb 2", { event });
    if (event.triggerSource == "UserMigration_Authentication") {
        console.log("1111");
        // Authenticate the user with your existing user directory service
        const user = authenticateUser(event.userName, event.request.password);
        console.log('user is ', user);
        if (user) {
            event.response.userAttributes = {
                email: user.emailAddress,
                email_verified: "true",
            };
            event.response.finalUserStatus = "CONFIRMED";
            event.response.messageAction = "SUPPRESS";
        }
    }
    return event;
});
exports.handler = handler;
// export const handler = async (event: any): Promise<any>=>{
//     console.log("we are in import-user-migratino handler")
//     return {
//         statusCode: 200,
//         headers: {
//             'Content-Type': 'text/html; charset=utf-8',
//         },
//         body: `<p>Hello Naji and Phil!</p>`,
//     }
// }
