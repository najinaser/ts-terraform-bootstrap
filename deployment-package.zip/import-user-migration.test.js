"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const import_user_migration_1 = require("./import-user-migration");
describe("import users", () => {
    test("many users", () => {
        expect((0, import_user_migration_1.authenticateUser)("naji.naser+31@moo.com", "12")).not.toBeNull();
        expect((0, import_user_migration_1.authenticateUser)("philip.cadwallader+30@moo.com", "1234")).not.toBeNull();
    });
});
